"use client";
import { useState } from "react";
import { doc, setDoc, writeBatch, deleteDoc } from "firebase/firestore";
import { db, ADMIN_EMAILS } from "@/lib/firebase";
import { useAuth, useMatches, useSettings } from "@/lib/hooks";
import { buildGroupFixtures, KNOCKOUT_STAGES, TEAMS, teamLabel } from "@/lib/worldcup2026";
import type { Match, Status } from "@/lib/types";

export default function AdminPage() {
  const { user, ready, isAdmin } = useAuth();
  const matches = useMatches();
  const settings = useSettings();
  const [msg, setMsg] = useState("");
  const [stage, setStage] = useState("R32");
  const [home, setHome] = useState("");
  const [away, setAway] = useState("");
  const [kick, setKick] = useState("");

  if (!ready) return null;
  if (!user || !isAdmin) {
    return <p className="mt-10 text-center text-muted">Admin access only.</p>;
  }

  const flash = (s: string) => { setMsg(s); setTimeout(() => setMsg(""), 2500); };

  const seedSettings = async () => {
    await setDoc(doc(db, "settings", "config"), {
      adminEmails: ADMIN_EMAILS, groupLocked: false, bracketLocked: false,
    }, { merge: true });
    flash("Settings doc created — security rules are now active.");
  };

  const seedGroups = async () => {
    const fixtures = buildGroupFixtures();
    const batch = writeBatch(db);
    fixtures.forEach((m) => batch.set(doc(db, "matches", m.id), m, { merge: true }));
    await batch.commit();
    flash("72 group fixtures created.");
  };

  const setLock = async (key: "groupLocked" | "bracketLocked", v: boolean) => {
    await setDoc(doc(db, "settings", "config"), { [key]: v }, { merge: true });
  };

  const updateMatch = async (m: Match, patch: Partial<Match>) => {
    await setDoc(doc(db, "matches", m.id), patch, { merge: true });
  };

  const addKnockout = async () => {
    if (!home || !away || home === away) return flash("Pick two different teams.");
    const n = matches.filter((x) => x.stage === stage).length + 1;
    const id = `${stage}-${String(n).padStart(2, "0")}`;
    await setDoc(doc(db, "matches", id), {
      id, stage, home, away, kickoff: kick || null, status: "scheduled",
    });
    setHome(""); setAway(""); setKick("");
    flash(`${id} added.`);
  };

  const stages = ["group", ...KNOCKOUT_STAGES.map((s) => s.key)];
  const list = (s: string) => matches.filter((m) => m.stage === s).sort((a, b) => a.id.localeCompare(b.id));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Admin dashboard</h1>
        {msg && <span className="text-sm text-bdi-lime">{msg}</span>}
      </div>

      <section className="card p-4">
        <h2 className="font-bold">Setup & locks</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          <button className="btn-ghost" onClick={seedSettings}>1. Create settings doc</button>
          <button className="btn-ghost" onClick={seedGroups}>2. Seed 72 group fixtures</button>
          <button className="btn-ghost" onClick={() => setLock("groupLocked", !settings.groupLocked)}>
            Group picks: {settings.groupLocked ? "LOCKED 🔒" : "open"}
          </button>
          <button className="btn-ghost" onClick={() => setLock("bracketLocked", !settings.bracketLocked)}>
            Bracket picks: {settings.bracketLocked ? "LOCKED 🔒" : "open"}
          </button>
        </div>
      </section>

      <section className="card p-4">
        <h2 className="font-bold">Add knockout tie</h2>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
          <select className="input max-w-[140px]" value={stage} onChange={(e) => setStage(e.target.value)}>
            {KNOCKOUT_STAGES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
          </select>
          <select className="input max-w-[200px]" value={home} onChange={(e) => setHome(e.target.value)}>
            <option value="">Home team…</option>
            {Object.keys(TEAMS).map((c) => <option key={c} value={c}>{TEAMS[c].flag} {TEAMS[c].name}</option>)}
          </select>
          <select className="input max-w-[200px]" value={away} onChange={(e) => setAway(e.target.value)}>
            <option value="">Away team…</option>
            {Object.keys(TEAMS).map((c) => <option key={c} value={c}>{TEAMS[c].flag} {TEAMS[c].name}</option>)}
          </select>
          <input className="input max-w-[210px]" type="datetime-local" value={kick} onChange={(e) => setKick(e.target.value)} />
          <button className="btn-primary" onClick={addKnockout}>Add</button>
        </div>
      </section>

      {stages.map((s) => {
        const ms = list(s);
        if (ms.length === 0) return null;
        return (
          <section key={s} className="card p-4">
            <h2 className="font-bold capitalize">{s === "group" ? "Group stage" : (KNOCKOUT_STAGES.find((k) => k.key === s)?.label || s)} — scores</h2>
            <div className="mt-3 space-y-2">
              {ms.map((m) => (
                <div key={m.id} className="flex flex-wrap items-center gap-2 border-b border-line/50 pb-2 text-sm">
                  <span className="w-14 font-mono text-xs text-muted">{m.id}</span>
                  <span className="min-w-[220px] flex-1 truncate">{teamLabel(m.home)} vs {teamLabel(m.away)}</span>
                  <input className="input !w-14 text-center" type="number" min={0} value={m.homeScore ?? ""}
                    placeholder="–" onChange={(e) => updateMatch(m, { homeScore: e.target.value === "" ? null as any : +e.target.value })} />
                  <input className="input !w-14 text-center" type="number" min={0} value={m.awayScore ?? ""}
                    placeholder="–" onChange={(e) => updateMatch(m, { awayScore: e.target.value === "" ? null as any : +e.target.value })} />
                  <select className="input !w-28" value={m.status}
                    onChange={(e) => updateMatch(m, { status: e.target.value as Status })}>
                    <option value="scheduled">scheduled</option>
                    <option value="live">LIVE</option>
                    <option value="final">final</option>
                  </select>
                  <input className="input !w-48" type="datetime-local" value={m.kickoff ? m.kickoff.slice(0, 16) : ""}
                    onChange={(e) => updateMatch(m, { kickoff: e.target.value ? new Date(e.target.value).toISOString() : null as any })} />
                  {s !== "group" && (
                    <button className="text-xs text-bdi-red underline" onClick={() => deleteDoc(doc(db, "matches", m.id))}>delete</button>
                  )}
                </div>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
