"use client";
import { useAuth, useMatches, useEveryone } from "@/lib/hooks";
import { scoreUser } from "@/lib/scoring";

export default function LeaderboardPage() {
  const { user } = useAuth();
  const matches = useMatches();
  const { users, allPicks } = useEveryone();

  const rows = Object.keys(users)
    .map((uid) => ({ uid, name: users[uid]?.name || "Player", ...scoreUser(allPicks[uid] || {}, matches) }))
    .sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));

  return (
    <div>
      <h1 className="text-2xl font-bold">Leaderboard</h1>
      <p className="mt-1 text-sm text-muted">Updates live as scores are entered. No refresh needed.</p>
      <div className="card mt-6 overflow-x-auto">
        <table className="w-full min-w-[480px] text-sm">
          <thead>
            <tr className="border-b border-line text-left text-[11px] uppercase tracking-wider text-muted">
              <th className="px-4 py-2.5 w-10">#</th>
              <th className="px-2 py-2.5">Player</th>
              <th className="px-2 py-2.5 text-right">Group</th>
              <th className="px-2 py-2.5 text-right">Bracket</th>
              <th className="px-2 py-2.5 text-right">Bonus</th>
              <th className="px-4 py-2.5 text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">No players yet.</td></tr>
            )}
            {rows.map((r, i) => (
              <tr key={r.uid}
                className={"border-b border-line/50 " + (user?.uid === r.uid ? "bg-bdi-blue/10" : "")}>
                <td className="px-4 py-2 font-mono text-muted">{i + 1}</td>
                <td className="px-2 py-2 font-medium">
                  {r.name}{user?.uid === r.uid && <span className="ml-2 text-[10px] text-bdi-blue">you</span>}
                </td>
                <td className="px-2 py-2 text-right font-mono">{r.group}</td>
                <td className="px-2 py-2 text-right font-mono">{r.bracket}</td>
                <td className="px-2 py-2 text-right font-mono">{r.bonus}</td>
                <td className="px-4 py-2 text-right font-mono font-bold text-bdi-lime">{r.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
