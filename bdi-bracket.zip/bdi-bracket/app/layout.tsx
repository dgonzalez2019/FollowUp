import type { Metadata, Viewport } from "next";
import "./globals.css";
import Nav from "@/components/Nav";

export const metadata: Metadata = {
  title: "BDI Bracket Challenge",
  description: "BDI Construction's World Cup 2026 pick'em — group predictions, knockout bracket, live leaderboard.",
};
export const viewport: Viewport = { themeColor: "#040507" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Nav />
        <main className="mx-auto max-w-5xl px-4 pb-20 pt-6">{children}</main>
      </body>
    </html>
  );
}
