"use client";
import Link from "next/link";
import { doc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth, useMatches, useMyPicks, useSettings, isLocked } from "@/lib/hooks";
import { outcomeOf } from "@/lib/scoring";
import { GROUPS, teamLabel } from "@/lib/worldcup2026";
import type { Match, Outcome } from "@/lib/types";

export default function GroupPicksPage() {
  const { user, ready } = useAuth();
  const matches = useMatches();
  const settings = useSettings();
  const picks = useMyPicks(user?.uid);

  if (ready && !user) {
    return <p className="mt-10 text-center text-muted">
      <Link href="/register" className="text-bdi-blue underline">Join the pool</Link> to make your picks.
    </p>;
  }

  const save = async (m: Match, o: Outcome) => {
    if (!user || isLocked(m, settings.groupLocked)) return;
    await setDoc(doc(db, "picks", user.uid), {
      group: { ...(picks.group || {}), [m.id]: o },
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  };

  const groups = Object.keys(GROUPS);
  const byGroup = (g: string) =>
    matches.filter((m) => m.stage === "group" && m.group === g).sort((a, b) => a.id.localeCompare(b.id));

  return (
    <div>
      <h1 className="text-2xl font-bold">Group-stage picks</h1>
      <p className="mt-1 text-sm text-muted">
        Pick the outcome of every match — home win, draw, or away win. 10 points each.
        Picks lock at kickoff{settings.groupLocked ? " (admin has locked all group picks)" : ""}.
      </p>
      {matches.filter((m) => m.stage === "group").length === 0 && (
        <p className="card mt-6 p-4 text-sm text-muted">Fixtures haven&apos;t been published yet — check back soon.</p>
      )}
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {groups.map((g) => {
          const ms = byGroup(g);
          if (ms.length === 0) return null;
          return (
            <section key={g} className="card p-4">
              <h2 className="mb-3 font-bold">Group {g}</h2>
              <div className="space-y-3">
                {ms.map((m) => {
                  const my = picks.group?.[m.id];
                  const result = outcomeOf(m);
                  const locked = isLocked(m, settings.groupLocked);
                  const cls = (o: Outcome) => {
                    if (result && my === o) return my === result ? "pick pick-good" : "pick pick-bad";
                    return "pick " + (my === o ? "pick-on" : "");
                  };
                  return (
                    <div key={m.id} className="text-sm">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate">{teamLabel(m.home)} <span className="text-muted">vs</span> {teamLabel(m.away)}</span>
                        {m.status !== "scheduled" && (
                          <span className={"font-mono text-xs font-bold " + (m.status === "live" ? "text-bdi-red" : "text-muted")}>
                            {m.homeScore ?? 0}–{m.awayScore ?? 0}{m.status === "live" ? " LIVE" : ""}
                          </span>
                        )}
                      </div>
                      <div className="mt-1.5 flex gap-1.5">
                        <button disabled={locked} className={cls("H")} onClick={() => save(m, "H")}>Home</button>
                        <button disabled={locked} className={cls("D")} onClick={() => save(m, "D")}>Draw</button>
                        <button disabled={locked} className={cls("A")} onClick={() => save(m, "A")}>Away</button>
                        {locked && m.status === "scheduled" && <span className="self-center text-xs text-muted">locked</span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}
