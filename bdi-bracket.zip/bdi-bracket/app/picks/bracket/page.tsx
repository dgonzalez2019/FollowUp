"use client";
import Link from "next/link";
import { doc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth, useMatches, useMyPicks, useSettings, isLocked } from "@/lib/hooks";
import { winnerOf, SCORING } from "@/lib/scoring";
import { KNOCKOUT_STAGES, TEAMS, teamLabel } from "@/lib/worldcup2026";
import type { Match } from "@/lib/types";

export default function BracketPage() {
  const { user, ready } = useAuth();
  const matches = useMatches();
  const settings = useSettings();
  const picks = useMyPicks(user?.uid);

  if (ready && !user) {
    return <p className="mt-10 text-center text-muted">
      <Link href="/register" className="text-bdi-blue underline">Join the pool</Link> to build your bracket.
    </p>;
  }

  const saveBracket = async (m: Match, team: string) => {
    if (!user || isLocked(m, settings.bracketLocked)) return;
    await setDoc(doc(db, "picks", user.uid), {
      bracket: { ...(picks.bracket || {}), [m.id]: team },
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  };

  const saveChampion = async (team: string) => {
    if (!user || settings.bracketLocked) return;
    await setDoc(doc(db, "picks", user.uid), {
      champion: team, updatedAt: new Date().toISOString(),
    }, { merge: true });
  };

  const stageMatches = (key: string) =>
    matches.filter((m) => m.stage === key).sort((a, b) => a.id.localeCompare(b.id));
  const anyKnockout = KNOCKOUT_STAGES.some((s) => stageMatches(s.key).length > 0);

  return (
    <div>
      <h1 className="text-2xl font-bold">Knockout bracket</h1>
      <p className="mt-1 text-sm text-muted">
        Pick the winner of every knockout tie. Points climb each round:
        R32 {SCORING.R32} · R16 {SCORING.R16} · QF {SCORING.QF} · SF {SCORING.SF} · Final {SCORING.F}.
      </p>

      <section className="card mt-6 p-4">
        <h2 className="font-bold">Champion bonus <span className="font-mono text-bdi-lime">+{SCORING.championBonus}</span></h2>
        <p className="mt-1 text-xs text-muted">Call the trophy winner before the knockouts lock.</p>
        <select className="input mt-3 max-w-xs" value={picks.champion || ""}
          disabled={!!settings.bracketLocked}
          onChange={(e) => saveChampion(e.target.value)}>
          <option value="">— pick your champion —</option>
          {Object.keys(TEAMS).map((c) => (
            <option key={c} value={c}>{TEAMS[c].flag} {TEAMS[c].name}</option>
          ))}
        </select>
      </section>

      {!anyKnockout && (
        <p className="card mt-4 p-4 text-sm text-muted">
          Knockout ties appear here once the Round of 32 is set (after the group stage ends June 27).
          Your champion pick is open now.
        </p>
      )}

      {KNOCKOUT_STAGES.map((s) => {
        const ms = stageMatches(s.key);
        if (ms.length === 0) return null;
        return (
          <section key={s.key} className="card mt-4 p-4">
            <h2 className="mb-3 font-bold">{s.label}</h2>
            <div className="grid gap-2 sm:grid-cols-2">
              {ms.map((m) => {
                const my = picks.bracket?.[m.id];
                const w = winnerOf(m);
                const locked = isLocked(m, settings.bracketLocked);
                const btn = (team: string) => {
                  let cls = "pick flex-1 truncate " + (my === team ? "pick-on" : "");
                  if (w && my === team) cls = "pick flex-1 truncate " + (w === team ? "pick-good" : "pick-bad");
                  return (
                    <button key={team} disabled={locked || team === "TBD"} className={cls}
                      onClick={() => saveBracket(m, team)}>
                      {team === "TBD" ? "TBD" : teamLabel(team)}
                    </button>
                  );
                };
                return (
                  <div key={m.id} className="rounded-lg border border-line p-2">
                    <div className="mb-1.5 flex items-center justify-between text-[11px] text-muted">
                      <span className="font-mono">{m.id}</span>
                      {m.status !== "scheduled" && (
                        <span className={"font-mono font-bold " + (m.status === "live" ? "text-bdi-red" : "")}>
                          {m.homeScore ?? 0}–{m.awayScore ?? 0}{m.status === "live" ? " LIVE" : ""}
                        </span>
                      )}
                    </div>
                    <div className="flex gap-1.5">{btn(m.home)}{btn(m.away)}</div>
                  </div>
                );
              })}
            </div>
          </section>
        );
      })}
    </div>
  );
}
