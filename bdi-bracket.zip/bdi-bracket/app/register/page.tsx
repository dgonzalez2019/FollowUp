"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

export default function RegisterPage() {
  const r = useRouter();
  const [mode, setMode] = useState<"signup" | "signin">("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const go = async () => {
    setErr(""); setBusy(true);
    try {
      if (mode === "signup") {
        if (!name.trim()) throw new Error("Enter your name — it shows on the leaderboard.");
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), pw);
        await updateProfile(cred.user, { displayName: name.trim() });
        await setDoc(doc(db, "users", cred.user.uid), {
          name: name.trim(), email: email.trim().toLowerCase(), createdAt: new Date().toISOString(),
        });
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), pw);
      }
      r.push("/picks/group");
    } catch (e: any) {
      setErr(e?.message?.replace("Firebase: ", "") || "Something went wrong.");
    } finally { setBusy(false); }
  };

  return (
    <div className="mx-auto mt-10 max-w-sm">
      <div className="card p-6">
        <h1 className="text-xl font-bold">{mode === "signup" ? "Join the pool" : "Welcome back"}</h1>
        <p className="mt-1 text-sm text-muted">
          {mode === "signup" ? "Free to play. Bragging rights are priceless." : "Sign in to manage your picks."}
        </p>
        <div className="mt-5 space-y-3">
          {mode === "signup" && (
            <input className="input" placeholder="Display name" value={name} onChange={(e) => setName(e.target.value)} />
          )}
          <input className="input" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input className="input" type="password" placeholder="Password (6+ characters)" value={pw}
            onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && go()} />
          {err && <p className="rounded-md border border-bdi-red/40 bg-bdi-red/10 px-3 py-2 text-xs text-bdi-red">{err}</p>}
          <button className="btn-primary w-full justify-center" disabled={busy} onClick={go}>
            {busy ? "One sec…" : mode === "signup" ? "Create account" : "Sign in"}
          </button>
          <button className="w-full text-center text-xs text-muted hover:text-ink"
            onClick={() => setMode(mode === "signup" ? "signin" : "signup")}>
            {mode === "signup" ? "Already registered? Sign in" : "New here? Create an account"}
          </button>
        </div>
      </div>
    </div>
  );
}
