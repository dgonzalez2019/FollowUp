"use client";
import Link from "next/link";
import { useAuth, useMatches, useEveryone } from "@/lib/hooks";
import { scoreUser } from "@/lib/scoring";
import { teamLabel } from "@/lib/worldcup2026";

export default function HomePage() {
  const { user } = useAuth();
  const matches = useMatches();
  const { users, allPicks } = useEveryone();

  const live = matches.filter((m) => m.status === "live");
  const top = Object.keys(users)
    .map((uid) => ({ uid, name: users[uid]?.name || "Player", ...scoreUser(allPicks[uid] || {}, matches) }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  return (
    <div className="space-y-8">
      <section className="pt-8 text-center">
        <div className="mx-auto mb-4 h-4 w-10 -skew-x-12 bg-gradient-to-r from-bdi-blue to-bdi-lime" />
        <h1 className="text-4xl font-extrabold tracking-tight">BDI Bracket Challenge</h1>
        <p className="mx-auto mt-3 max-w-xl text-muted">
          World Cup 2026 pick&apos;em for the BDI crew. Call every group match, build your
          knockout bracket, and fight for the top of the leaderboard all summer.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          {!user && <Link href="/register" className="btn-primary">Join the pool</Link>}
          <Link href="/picks/group" className={user ? "btn-primary" : "btn-ghost"}>Make picks</Link>
          <Link href="/leaderboard" className="btn-ghost">Leaderboard</Link>
        </div>
      </section>

      {live.length > 0 && (
        <section className="card p-4">
          <h2 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-bdi-red">
            <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-bdi-red" /> Live now
          </h2>
          <div className="space-y-2">
            {live.map((m) => (
              <div key={m.id} className="flex items-center justify-between text-sm">
                <span>{teamLabel(m.home)} vs {teamLabel(m.away)}</span>
                <span className="font-mono font-bold">{m.homeScore ?? 0} – {m.awayScore ?? 0}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="card p-4">
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-muted">Top of the table</h2>
        {top.length === 0 && <p className="text-sm text-muted">No players yet — be the first to join.</p>}
        <ol className="space-y-1.5">
          {top.map((r, i) => (
            <li key={r.uid} className="flex items-center gap-3 text-sm">
              <span className="w-5 text-right font-mono text-muted">{i + 1}</span>
              <span className="flex-1">{r.name}</span>
              <span className="font-mono font-bold text-bdi-lime">{r.total}</span>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
