"use client";
import { useEffect, useState } from "react";
import { onAuthStateChanged, type User } from "firebase/auth";
import { collection, doc, onSnapshot } from "firebase/firestore";
import { auth, db, ADMIN_EMAILS } from "./firebase";
import type { Match, Picks, Settings, UserDoc } from "./types";

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => onAuthStateChanged(auth, (u) => { setUser(u); setReady(true); }), []);
  const isAdmin = !!user?.email && ADMIN_EMAILS.includes(user.email.toLowerCase());
  return { user, ready, isAdmin };
}

export function useMatches() {
  const [matches, setMatches] = useState<Match[]>([]);
  useEffect(() => onSnapshot(collection(db, "matches"), (snap) => {
    setMatches(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Match));
  }), []);
  return matches;
}

export function useSettings() {
  const [settings, setSettings] = useState<Settings>({ adminEmails: [] });
  useEffect(() => onSnapshot(doc(db, "settings", "config"), (d) => {
    if (d.exists()) setSettings(d.data() as Settings);
  }), []);
  return settings;
}

export function useMyPicks(uid?: string) {
  const [picks, setPicks] = useState<Picks>({});
  useEffect(() => {
    if (!uid) return;
    return onSnapshot(doc(db, "picks", uid), (d) => setPicks((d.data() as Picks) || {}));
  }, [uid]);
  return picks;
}

export function useEveryone() {
  const [users, setUsers] = useState<Record<string, UserDoc>>({});
  const [allPicks, setAllPicks] = useState<Record<string, Picks>>({});
  useEffect(() => onSnapshot(collection(db, "users"), (snap) => {
    const o: Record<string, UserDoc> = {};
    snap.docs.forEach((d) => (o[d.id] = d.data() as UserDoc));
    setUsers(o);
  }), []);
  useEffect(() => onSnapshot(collection(db, "picks"), (snap) => {
    const o: Record<string, Picks> = {};
    snap.docs.forEach((d) => (o[d.id] = d.data() as Picks));
    setAllPicks(o);
  }), []);
  return { users, allPicks };
}

export function isLocked(m: Match, globalLock?: boolean) {
  if (globalLock) return true;
  if (m.status !== "scheduled") return true;
  if (m.kickoff && new Date(m.kickoff).getTime() <= Date.now()) return true;
  return false;
}
