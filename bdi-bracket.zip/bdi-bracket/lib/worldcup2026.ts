// FIFA World Cup 2026 — final draw (verified June 2026)
export const GROUPS: Record<string, string[]> = {
  A: ["MEX", "RSA", "KOR", "CZE"],
  B: ["CAN", "BIH", "QAT", "SUI"],
  C: ["BRA", "MAR", "HAI", "SCO"],
  D: ["USA", "PAR", "AUS", "TUR"],
  E: ["GER", "CUW", "CIV", "ECU"],
  F: ["NED", "JPN", "SWE", "TUN"],
  G: ["BEL", "EGY", "IRN", "NZL"],
  H: ["ESP", "CPV", "KSA", "URU"],
  I: ["FRA", "SEN", "IRQ", "NOR"],
  J: ["ARG", "ALG", "AUT", "JOR"],
  K: ["POR", "COD", "UZB", "COL"],
  L: ["ENG", "CRO", "GHA", "PAN"],
};

export const TEAMS: Record<string, { name: string; flag: string }> = {
  MEX: { name: "Mexico", flag: "🇲🇽" }, RSA: { name: "South Africa", flag: "🇿🇦" },
  KOR: { name: "South Korea", flag: "🇰🇷" }, CZE: { name: "Czechia", flag: "🇨🇿" },
  CAN: { name: "Canada", flag: "🇨🇦" }, BIH: { name: "Bosnia & Herzegovina", flag: "🇧🇦" },
  QAT: { name: "Qatar", flag: "🇶🇦" }, SUI: { name: "Switzerland", flag: "🇨🇭" },
  BRA: { name: "Brazil", flag: "🇧🇷" }, MAR: { name: "Morocco", flag: "🇲🇦" },
  HAI: { name: "Haiti", flag: "🇭🇹" }, SCO: { name: "Scotland", flag: "🏴󠁧󠁢󠁳󠁣󠁴󠁿" },
  USA: { name: "United States", flag: "🇺🇸" }, PAR: { name: "Paraguay", flag: "🇵🇾" },
  AUS: { name: "Australia", flag: "🇦🇺" }, TUR: { name: "Türkiye", flag: "🇹🇷" },
  GER: { name: "Germany", flag: "🇩🇪" }, CUW: { name: "Curaçao", flag: "🇨🇼" },
  CIV: { name: "Ivory Coast", flag: "🇨🇮" }, ECU: { name: "Ecuador", flag: "🇪🇨" },
  NED: { name: "Netherlands", flag: "🇳🇱" }, JPN: { name: "Japan", flag: "🇯🇵" },
  SWE: { name: "Sweden", flag: "🇸🇪" }, TUN: { name: "Tunisia", flag: "🇹🇳" },
  BEL: { name: "Belgium", flag: "🇧🇪" }, EGY: { name: "Egypt", flag: "🇪🇬" },
  IRN: { name: "Iran", flag: "🇮🇷" }, NZL: { name: "New Zealand", flag: "🇳🇿" },
  ESP: { name: "Spain", flag: "🇪🇸" }, CPV: { name: "Cape Verde", flag: "🇨🇻" },
  KSA: { name: "Saudi Arabia", flag: "🇸🇦" }, URU: { name: "Uruguay", flag: "🇺🇾" },
  FRA: { name: "France", flag: "🇫🇷" }, SEN: { name: "Senegal", flag: "🇸🇳" },
  IRQ: { name: "Iraq", flag: "🇮🇶" }, NOR: { name: "Norway", flag: "🇳🇴" },
  ARG: { name: "Argentina", flag: "🇦🇷" }, ALG: { name: "Algeria", flag: "🇩🇿" },
  AUT: { name: "Austria", flag: "🇦🇹" }, JOR: { name: "Jordan", flag: "🇯🇴" },
  POR: { name: "Portugal", flag: "🇵🇹" }, COD: { name: "DR Congo", flag: "🇨🇩" },
  UZB: { name: "Uzbekistan", flag: "🇺🇿" }, COL: { name: "Colombia", flag: "🇨🇴" },
  ENG: { name: "England", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿" }, CRO: { name: "Croatia", flag: "🇭🇷" },
  GHA: { name: "Ghana", flag: "🇬🇭" }, PAN: { name: "Panama", flag: "🇵🇦" },
};

export const teamLabel = (code: string) =>
  TEAMS[code] ? `${TEAMS[code].flag} ${TEAMS[code].name}` : code;

// standard 4-team round robin: 6 matches per group
const RR: [number, number][] = [[0, 1], [2, 3], [0, 2], [3, 1], [3, 0], [1, 2]];

export function buildGroupFixtures() {
  const matches: any[] = [];
  for (const [g, teams] of Object.entries(GROUPS)) {
    RR.forEach(([h, a], i) => {
      matches.push({
        id: `G${g}${i + 1}`,
        stage: "group", group: g,
        home: teams[h], away: teams[a],
        status: "scheduled",
      });
    });
  }
  return matches;
}

export const KNOCKOUT_STAGES = [
  { key: "R32", label: "Round of 32", count: 16 },
  { key: "R16", label: "Round of 16", count: 8 },
  { key: "QF",  label: "Quarterfinals", count: 4 },
  { key: "SF",  label: "Semifinals", count: 2 },
  { key: "F",   label: "Final", count: 1 },
];
