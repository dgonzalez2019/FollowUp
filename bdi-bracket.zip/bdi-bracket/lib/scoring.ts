import type { Match, Picks } from "./types";

/**
 * ESPN-style World Cup scoring
 * - Group stage: 10 pts per correct match outcome (win/draw/win)
 * - Knockout: escalating points per correct winner
 * - Champion bonus: picked the trophy winner before knockouts
 */
export const SCORING = {
  group: 10,
  R32: 20,
  R16: 40,
  QF: 60,
  SF: 80,
  F: 100,
  championBonus: 80,
};

export function outcomeOf(m: Match): "H" | "D" | "A" | null {
  if (m.status !== "final" || m.homeScore == null || m.awayScore == null) return null;
  if (m.homeScore > m.awayScore) return "H";
  if (m.homeScore < m.awayScore) return "A";
  return "D";
}

export function winnerOf(m: Match): string | null {
  const o = outcomeOf(m);
  if (o === "H") return m.home;
  if (o === "A") return m.away;
  return null; // knockout draws decided by admin entering the deciding score
}

export function scoreUser(picks: Picks, matches: Match[]) {
  let group = 0, bracket = 0, bonus = 0;
  let finalWinner: string | null = null;

  for (const m of matches) {
    if (m.stage === "group") {
      const p = picks.group?.[m.id];
      const o = outcomeOf(m);
      if (p && o && p === o) group += SCORING.group;
    } else {
      const w = winnerOf(m);
      if (m.stage === "F" && w) finalWinner = w;
      const p = picks.bracket?.[m.id];
      if (p && w && p === w) bracket += (SCORING as any)[m.stage] || 0;
    }
  }
  if (picks.champion && finalWinner && picks.champion === finalWinner) {
    bonus = SCORING.championBonus;
  }
  return { group, bracket, bonus, total: group + bracket + bonus };
}
