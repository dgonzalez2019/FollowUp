export type Stage = "group" | "R32" | "R16" | "QF" | "SF" | "F";
export type Status = "scheduled" | "live" | "final";
export type Outcome = "H" | "D" | "A";

export interface Match {
  id: string;
  stage: Stage;
  group?: string;        // A..L for group stage
  home: string;          // team code or "TBD"
  away: string;
  kickoff?: string;      // ISO datetime, optional
  status: Status;
  homeScore?: number;
  awayScore?: number;
}

export interface Picks {
  group?: Record<string, Outcome>;   // matchId -> H/D/A
  bracket?: Record<string, string>;  // matchId -> winning team code
  champion?: string;                 // team code
  updatedAt?: string;
}

export interface UserDoc { name: string; email: string; createdAt: string; }

export interface Settings {
  adminEmails: string[];
  groupLocked?: boolean;
  bracketLocked?: boolean;
}
