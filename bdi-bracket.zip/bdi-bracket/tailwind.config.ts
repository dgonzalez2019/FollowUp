import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#eceef0",
        muted: "#9aa3ad",
        line: "#1c2026",
        surface: "#0e1014",
        surface2: "#171a1f",
        bdi: { blue: "#2f9be0", blued: "#1f7fc0", lime: "#b7d44a", red: "#e06149" },
      },
    },
  },
  plugins: [],
};
export default config;
