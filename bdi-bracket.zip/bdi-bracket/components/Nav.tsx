"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useAuth } from "@/lib/hooks";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/picks/group", label: "Group Picks" },
  { href: "/picks/bracket", label: "Bracket" },
  { href: "/leaderboard", label: "Leaderboard" },
];

export default function Nav() {
  const path = usePathname();
  const { user, isAdmin } = useAuth();
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-[#06070a]/90 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center gap-1 overflow-x-auto px-4 py-3">
        <span className="mr-3 flex items-center gap-2 whitespace-nowrap font-bold tracking-tight">
          <span className="inline-block h-3 w-5 -skew-x-12 bg-gradient-to-r from-bdi-blue to-bdi-lime" />
          BDI Bracket
        </span>
        {LINKS.map((l) => (
          <Link key={l.href} href={l.href}
            className={"whitespace-nowrap rounded-md px-3 py-1.5 text-sm " +
              (path === l.href ? "bg-surface2 text-ink font-semibold" : "text-muted hover:text-ink")}>
            {l.label}
          </Link>
        ))}
        {isAdmin && (
          <Link href="/admin" className={"whitespace-nowrap rounded-md px-3 py-1.5 text-sm " +
            (path === "/admin" ? "bg-surface2 text-ink font-semibold" : "text-bdi-lime hover:text-ink")}>
            Admin
          </Link>
        )}
        <span className="flex-1" />
        {user ? (
          <button onClick={() => signOut(auth)} className="whitespace-nowrap text-sm text-muted hover:text-ink">
            Sign out
          </button>
        ) : (
          <Link href="/register" className="btn-primary whitespace-nowrap !py-1.5">Join</Link>
        )}
      </div>
    </header>
  );
}
