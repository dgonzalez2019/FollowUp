# BDI Bracket Challenge

World Cup 2026 pick'em for BDI Construction — Next.js 15, Firebase, deployed on Vercel.
Public registration, group-stage predictions, knockout bracket, live-updating leaderboard,
and an admin dashboard for scores.

## Scoring (ESPN-style)
| What | Points |
|---|---|
| Correct group-match outcome (W/D/L) | 10 |
| Correct Round-of-32 winner | 20 |
| Correct Round-of-16 winner | 40 |
| Correct Quarterfinal winner | 60 |
| Correct Semifinal winner | 80 |
| Correct Final winner | 100 |
| Champion bonus (picked before knockouts) | 80 |

Edit `lib/scoring.ts` to change values.

## Setup (15 minutes)
1. **Firebase** (you already have an account from BDI University):
   - console.firebase.google.com → Add project (e.g. `bdi-bracket`)
   - Build → Authentication → Sign-in method → enable **Email/Password**
   - Build → Firestore Database → Create database (production mode)
   - Firestore → Rules → paste the contents of `firestore.rules` → Publish
   - Project settings → Your apps → Web app → copy the config values
2. **Local env**: copy `.env.example` to `.env.local` and fill in the Firebase values.
   Put your email in `NEXT_PUBLIC_ADMIN_EMAILS` (comma-separated for multiple admins).
3. **Run locally**: `npm install` then `npm run dev`
4. **First-run seeding** (visit `/admin` signed in as an admin):
   - Click **"1. Create settings doc"** (activates the security rules' admin list)
   - Click **"2. Seed 72 group fixtures"** (real 2026 groups A–L, already in the code)
   - Optionally set kickoff times per match — picks auto-lock at kickoff

## Deploy to Vercel
1. Push this folder to a GitHub repo
2. vercel.com → Add New → Project → import the repo (Next.js auto-detected; `vercel.json` included)
3. Add the same environment variables from `.env.local` in Project → Settings → Environment Variables
4. Deploy. Then update `BRACKET_URL` in BDI University's index.html to your live URL.

## Running the tournament
- **Live scores**: open `/admin` during matches, type the score, set status to LIVE —
  every player's leaderboard updates in realtime (Firestore listeners, no refresh).
  Set status to **final** when the whistle blows; points are awarded from finals only.
- **Knockouts**: after groups end (June 27), add the 16 Round-of-32 ties in `/admin`;
  players then pick winners round by round. Knockout draws: enter the deciding
  score (after ET/pens) so a winner exists.
- **Locks**: per-match at kickoff automatically, or flip the global locks anytime.
